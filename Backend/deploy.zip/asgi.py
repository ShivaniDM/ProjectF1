from main import app

# This is needed for Gunicorn to find the ASGI application
application = app